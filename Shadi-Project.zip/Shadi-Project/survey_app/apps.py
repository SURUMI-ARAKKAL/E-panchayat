from django.apps import AppConfig


class SurveyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'survey_app'

